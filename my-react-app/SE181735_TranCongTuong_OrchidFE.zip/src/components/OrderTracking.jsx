import { useState } from 'react';
import { Container, Row, Col, Card, Table, Badge } from 'react-bootstrap';
import '../style/OrderTracking.css';

// Mock data for user orders
const mockOrders = [
  {
    id: 'ORD001',
    userId: '123',
    items: [
      { id: '2', orchidName: 'Ceasar 4N', quantity: 2, price: 29.99 },
      { id: '1', orchidName: 'Dendrobium', quantity: 1, price: 19.99 }
    ],
    total: 79.97,
    status: 'Pending',
    createdAt: '2025-06-07'
  },
  {
    id: 'ORD002',
    userId: '123',
    items: [{ id: '3', orchidName: 'Phalaenopsis', quantity: 1, price: 24.99 }],
    total: 24.99,
    status: 'Confirmed',
    createdAt: '2025-06-06'
  },
  {
    id: 'ORD003',
    userId: '123',
    items: [{ id: '2', orchidName: 'Ceasar 4N', quantity: 1, price: 29.99 }],
    total: 29.99,
    status: 'Completed',
    createdAt: '2025-06-05'
  },
  {
    id: 'ORD004',
    userId: '123',
    items: [{ id: '1', orchidName: 'Dendrobium', quantity: 2, price: 19.99 }],
    total: 39.98,
    status: 'Cancelled',
    createdAt: '2025-06-04'
  }
];

export default function OrderTracking() {
  const user = JSON.parse(localStorage.getItem('user'));
  const [orders] = useState(mockOrders.filter(order => order.userId === user?.id));

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Pending':
        return <Badge bg="warning">Pending</Badge>;
      case 'Confirmed':
        return <Badge bg="info">Confirmed</Badge>;
      case 'Completed':
        return <Badge bg="success">Completed</Badge>;
      case 'Cancelled':
        return <Badge bg="danger">Cancelled</Badge>;
      default:
        return <Badge bg="secondary">Unknown</Badge>;
    }
  };

  return (
    <Container className="order-tracking-container" style={{ minHeight: '100vh', padding: '20px' }}>
      <h2>Order Tracking</h2>
      <Row>
        <Col>
          {orders.length === 0 ? (
            <p>No orders found.</p>
          ) : (
            orders.map(order => (
              <Card key={order.id} className="mb-3">
                <Card.Body>
                  <Card.Title>Order #{order.id}</Card.Title>
                  <Card.Subtitle className="mb-2 text-muted">
                    Placed on: {order.createdAt} | Status: {getStatusBadge(order.status)}
                  </Card.Subtitle>
                  <Table striped bordered hover size="sm">
                    <thead>
                      <tr>
                        <th>Orchid</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {order.items.map(item => (
                        <tr key={item.id}>
                          <td>{item.orchidName}</td>
                          <td>{item.quantity}</td>
                          <td>${item.price.toFixed(2)}</td>
                          <td>${(item.quantity * item.price).toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                  <Card.Text>
                    <strong>Total: </strong>${order.total.toFixed(2)}
                  </Card.Text>
                </Card.Body>
              </Card>
            ))
          )}
        </Col>
      </Row>
    </Container>
  );
}