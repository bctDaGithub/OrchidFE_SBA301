import React, { useState } from 'react';
import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBInput,
  MDBIcon,
  MDBCheckbox
} from 'mdb-react-ui-kit';
import 'mdb-react-ui-kit/dist/css/mdb.min.css';
import '../style/LoginForm.css';
import { useNavigate } from 'react-router-dom';

// Dữ liệu giả cho người dùng
const mockUsers = [
  {
    email: 'admin@example.com',
    password: 'Admin123!',
    fullName: 'Admin User',
    role: 'admin'
  },
  {
    email: 'user@example.com',
    password: 'User123!',
    fullName: 'Regular User',
    role: 'user'
  }
];

function LoginForm() {
  const [isLogin, setIsLogin] = useState(true);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    const user = mockUsers.find(
      (u) => u.email === email && u.password === password
    );
    if (user) {
      localStorage.setItem('user', JSON.stringify({ email: user.email, role: user.role }));
      setError('');
      navigate('/');
      window.location.reload();
    } else {
      setError('Invalid email or password');
    }
  };

  const handleRegister = () => {
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    if (password.length < 8) {
      setError('Password must be at least 8 characters');
      return;
    }
    if (mockUsers.find((u) => u.email === email)) {
      setError('Email already exists');
      return;
    }
    // Thêm người dùng mới vào mockUsers (chỉ trong bộ nhớ, không lưu vĩnh viễn)
    const newUser = { email, password, fullName, role: 'user' };
    mockUsers.push(newUser);
    localStorage.setItem('user', JSON.stringify({ email, role: 'user' }));
    setError('');
    navigate('/');
    window.location.reload();
  };

  const handleForgotPasswordSubmit = () => {
    if (mockUsers.find((u) => u.email === email)) {
      setError('Reset link sent to your email (simulated).');
    } else {
      setError('Email not found');
    }
  };

  const toggleForm = () => {
    setIsLogin(!isLogin);
    setIsForgotPassword(false);
    setError('');
    setEmail('');
    setPassword('');
    setFullName('');
    setConfirmPassword('');
  };

  const renderLoginForm = () => (
    <>
      <h2 className="form-title">Sign in</h2>
      <p className="form-subtitle">Please enter your login and password!</p>
      {error && <p className="text-danger">{error}</p>}

      <MDBInput
        wrapperClass='mb-4'
        label='Email address'
        id='email'
        type='email'
        size="lg"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <MDBInput
        wrapperClass='mb-4'
        label='Password'
        id='password'
        type='password'
        size="lg"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />

      <div className="d-flex justify-content-between mb-4">
        <MDBCheckbox name='flexCheck' id='flexCheckDefault' label='Remember password' />
        <a className="form-link" onClick={() => setIsForgotPassword(true)}>Forgot password?</a>
      </div>

      <MDBBtn size='lg' className='w-100 mb-4' onClick={handleLogin}>
        Login
      </MDBBtn>

      <hr className="my-4" />

      <MDBBtn className="mb-4 w-100" size="lg" style={{backgroundColor: '#dd4b39'}} disabled>
        <MDBIcon fab icon="google" className="mx-2"/>
        Sign in with Google (Disabled)
      </MDBBtn>

      <div className="toggle-form">
        <p>Don't have an account? <a className="form-link" onClick={toggleForm}>Register</a></p>
      </div>
    </>
  );

  const renderRegisterForm = () => (
    <>
      <h2 className="form-title">Create Account</h2>
      <p className="form-subtitle">Please fill in your details!</p>
      {error && <p className="text-danger">{error}</p>}

      <MDBInput
        wrapperClass='mb-4'
        label='Full Name'
        id='name'
        type='text'
        size="lg"
        value={fullName}
        onChange={(e) => setFullName(e.target.value)}
      />
      <MDBInput
        wrapperClass='mb-4'
        label='Email address'
        id='email'
        type='email'
        size="lg"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <MDBInput
        wrapperClass='mb-4'
        label='Password'
        id='password'
        type='password'
        size="lg"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <MDBInput
        wrapperClass='mb-4'
        label='Confirm Password'
        id='confirmPassword'
        type='password'
        size="lg"
        value={confirmPassword}
        onChange={(e) => setConfirmPassword(e.target.value)}
      />

      <div className="password-requirements">
        Password must contain at least 8 characters, including uppercase, lowercase, numbers and special characters
      </div>

      <MDBBtn size='lg' className='w-100 mb-4 mt-4' onClick={handleRegister}>
        Register
      </MDBBtn>

      <div className="toggle-form">
        <p>Already have an account? <a className="form-link" onClick={toggleForm}>Login</a></p>
      </div>
    </>
  );

  const renderForgotPasswordForm = () => (
    <>
      <h2 className="form-title">Reset Password</h2>
      <p className="form-subtitle">Enter your email to reset your password</p>
      {error && <p className="text-danger">{error}</p>}

      <MDBInput
        wrapperClass='mb-4'
        label='Email address'
        id='email'
        type='email'
        size="lg"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />

      <MDBBtn size='lg' className='w-100 mb-4' onClick={handleForgotPasswordSubmit}>
        Send Reset Link
      </MDBBtn>

      <div className="toggle-form">
        <p>Remember your password? <a className="form-link" onClick={() => setIsForgotPassword(false)}>Back to Login</a></p>
      </div>
    </>
  );

  return (
    <div className="login-container">
      <MDBContainer>
        <MDBRow className='d-flex justify-content-center align-items-center'>
          <MDBCol col='12'>
            <MDBCard className='bg-white my-5 mx-auto form-container' style={{borderRadius: '1rem'}}>
              <MDBCardBody className='p-5 w-100 d-flex flex-column'>
                {isForgotPassword ? renderForgotPasswordForm() : (isLogin ? renderLoginForm() : renderRegisterForm())}
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </div>
  );
}

export default LoginForm;