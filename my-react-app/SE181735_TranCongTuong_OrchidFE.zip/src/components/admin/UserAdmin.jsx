import React, { useEffect, useState } from 'react';
import { Container, Table, Button, Form, InputGroup, Badge } from 'react-bootstrap';
import toast, { Toaster } from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import './style/UserAdmin.css';

// Dữ liệu giả cho người dùng
const mockUsers = [
  {
    id: '1',
    email: 'admin@example.com',
    fullName: 'Admin User',
    role: 'admin'
  },
  {
    id: '2',
    email: 'user@example.com',
    fullName: 'Regular User',
    role: 'user'
  },
  {
    id: '3',
    email: 'john.doe@example.com',
    fullName: 'John Doe',
    role: 'user'
  },
  {
    id: '4',
    email: 'jane.smith@example.com',
    fullName: 'Jane Smith',
    role: 'admin'
  }
];

export default function UserAdmin() {
  const [users, setUsers] = useState(mockUsers);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user'));
  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    if (!user || !isAdmin) {
      toast.error('Access denied. Admins only.');
      navigate('/login');
    }
  }, [navigate, user, isAdmin]);

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      setUsers(users.filter((user) => user.id !== id));
      toast.success('User deleted successfully!');
    }
  };

  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleRoleFilter = (e) => {
    setRoleFilter(e.target.value);
  };

  // Lọc và tìm kiếm user
  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole =
      roleFilter === 'all' || user.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  return (
    <Container className="user-admin-container py-8">
      <Toaster />
      <h1 className="text-3xl font-bold text-center mb-6 text-primary">Admin User Management</h1>
      <div className="mb-4 flex flex-col sm:flex-row gap-4 justify-between">
        <InputGroup className="w-full sm:w-1/2">
          <InputGroup.Text>
            <i className="bi bi-search"></i>
          </InputGroup.Text>
          <Form.Control
            type="text"
            placeholder="Search by name or email..."
            value={searchQuery}
            onChange={handleSearch}
            className="border-gray-300 focus:ring-blue-500"
          />
        </InputGroup>
        <Form.Select
          className="w-full sm:w-1/4 border-gray-300 focus:ring-blue-500"
          value={roleFilter}
          onChange={handleRoleFilter}
        >
          <option value="all">All Roles</option>
          <option value="admin">Admin</option>
          <option value="user">User</option>
        </Form.Select>
      </div>
      <Table striped bordered hover responsive className="user-table shadow-sm">
        <thead className="bg-primary text-white">
          <tr>
            <th>Email</th>
            <th>Full Name</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredUsers.length > 0 ? (
            filteredUsers.map((user) => (
              <tr key={user.id} className="hover:bg-gray-50 transition">
                <td className="align-middle">{user.email}</td>
                <td className="align-middle">{user.fullName}</td>
                <td className="align-middle">
                  {user.role === 'admin' ? (
                    <Badge bg="success">Admin</Badge>
                  ) : (
                    <Badge bg="warning">User</Badge>
                  )}
                </td>
                <td className="align-middle">
                  <Button
                    variant="outline-danger"
                    size="sm"
                    className="action-button"
                    onClick={() => handleDelete(user.id)}
                  >
                    <i className="bi bi-trash3 me-1"></i>Delete
                  </Button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4" className="text-center py-4">
                No users found.
              </td>
            </tr>
          )}
        </tbody>
      </Table>
    </Container>
  );
}