import React, { useEffect, useState } from 'react';
import { Container, Table, Button, Modal, Form, Image, Badge } from 'react-bootstrap';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import { useForm, Controller } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBTable,
  MDBTableHead,
  MDBTableBody,
  MDBBtn,
  MDBInput,
  MDBModal,
  MDBModalDialog,
  MDBModalContent,
  MDBModalHeader,
  MDBModalTitle,
  MDBModalBody,
  MDBModalFooter,
  MDBIcon
} from 'mdb-react-ui-kit';
import './style/OrchidAdmin.css';   

export default function OrchidAdmin() {
  const baseUrl = import.meta.env.VITE_API_URL || 'https://65e0222ad3db23f7624859a6.mockapi.io/Java'; // Fallback to MockAPI URL
  const [orchids, setOrchids] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editId, setEditId] = useState(null);
  const navigate = useNavigate();
  const { register, handleSubmit, formState: { errors }, reset, setValue, control } = useForm();
  const user = JSON.parse(localStorage.getItem('user'));
  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    console.log('VITE_API_URL:', baseUrl); // Debug: Kiểm tra URL API
    console.log('User:', user); // Debug: Kiểm tra user từ localStorage
    if (!user || !isAdmin) {
      toast.error('Access denied. Admins only.');
      navigate('/login');
    } else {
      fetchData();
    }
  }, [navigate, user, isAdmin]);

  const fetchData = async () => {
    try {
      console.log('Fetching data from:', baseUrl); // Debug: Log URL gọi API
      const response = await axios.get(baseUrl);
      console.log('API Response:', response.data); // Debug: Log dữ liệu trả về
      if (response.data && Array.isArray(response.data)) {
        const sortedData = response.data.sort((a, b) => parseInt(b.id) - parseInt(a.id));
        setOrchids(sortedData);
        if (sortedData.length === 0) {
          toast.info('No orchids found in the database.');
        }
      } else {
        console.warn('Invalid API response:', response.data); // Debug: Log dữ liệu không hợp lệ
        toast.error('Invalid data format from API.');
        setOrchids([]);
      }
    } catch (error) {
      console.error('Error fetching orchids:', error.message, error.response); // Debug: Log chi tiết lỗi
      toast.error(`Failed to fetch orchids: ${error.message}`);
      setOrchids([]);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this orchid?')) {
      try {
        await axios.delete(`${baseUrl}/${id}`);
        toast.success('Orchid deleted successfully!');
        fetchData();
      } catch (error) {
        console.error('Error deleting orchid:', error.message, error.response);
        toast.error('Failed to delete orchid.');
      }
    }
  };

  const handleShowAdd = () => {
    setIsEditMode(false);
    reset();
    setShowModal(true);
  };

  const handleShowEdit = (orchid) => {
    setIsEditMode(true);
    setEditId(orchid.id);
    setValue('orchidName', orchid.orchidName);
    setValue('image', orchid.image);
    setValue('isNatural', orchid.isNatural);
    setShowModal(true);
  };

  const handleClose = () => {
    setShowModal(false);
    reset();
  };

  const onSubmit = async (data) => {
    try {
      if (isEditMode) {
        await axios.put(`${baseUrl}/${editId}`, data, {
          headers: { 'Content-Type': 'application/json' }
        });
        toast.success('Orchid updated successfully!');
      } else {
        await axios.post(baseUrl, data, {
          headers: { 'Content-Type': 'application/json' }
        });
        toast.success('Orchid added successfully!');
      }
      fetchData();
      handleClose();
    } catch (error) {
      console.error('Error saving orchid:', error.message, error.response);
      toast.error(isEditMode ? 'Failed to update orchid.' : 'Failed to add orchid.');
    }
  };

  return (
    <Container className="orchid-admin-container py-8">
      <Toaster />
      <h1 className="text-3xl font-bold text-center mb-6 text-primary">Admin Orchid Management</h1>
      <div className="mb-4 text-right">
        <Button variant="primary" onClick={handleShowAdd} className="add-button">
          <i className="bi bi-plus-circle me-2"></i>Add New Orchid
        </Button>
      </div>
      <Table striped bordered hover responsive className="orchid-table shadow-sm">
        <thead className="bg-primary text-white">
          <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Origin</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {orchids.length > 0 ? (
            orchids.map((orchid) => (
              <tr key={orchid.id} className="hover:bg-gray-50 transition">
                <td className="align-middle">
                  <Image src={orchid.image} rounded width={100} className="orchid-image shadow-sm" />
                </td>
                <td className="align-middle">{orchid.orchidName}</td>
                <td className="align-middle">
                  {orchid.isNatural ? (
                    <Badge bg="success">Natural</Badge>
                  ) : (
                    <Badge bg="warning">Industry</Badge>
                  )}
                </td>
                <td className="align-middle">
                  <Button
                    variant="outline-primary"
                    size="sm"
                    className="me-2 action-button"
                    onClick={() => handleShowEdit(orchid)}
                  >
                    <i className="bi bi-pencil-square me-1"></i>Edit
                  </Button>
                  <Button
                    variant="outline-danger"
                    size="sm"
                    className="action-button"
                    onClick={() => handleDelete(orchid.id)}
                  >
                    <i className="bi bi-trash3 me-1"></i>Delete
                  </Button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4" className="text-center py-4">
                No orchids found. Please add some orchids.
              </td>
            </tr>
          )}
        </tbody>
      </Table>

      <Modal show={showModal} onHide={handleClose} backdrop="static" centered>
        <Modal.Header closeButton className="bg-primary text-white">
          <Modal.Title>{isEditMode ? 'Edit Orchid' : 'Add New Orchid'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit(onSubmit)}>
            <Form.Group className="mb-3" controlId="orchidName">
              <Form.Label className="font-semibold">Orchid Name</Form.Label>
              <Controller
                name="orchidName"
                control={control}
                rules={{ required: 'Orchid name is required' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter orchid name"
                    className="border-gray-300 focus:ring-primary"
                    autoFocus
                  />
                )}
              />
              {errors.orchidName && (
                <p className="text-danger mt-1">{errors.orchidName.message}</p>
              )}
            </Form.Group>
            <Form.Group className="mb-3" controlId="image">
              <Form.Label className="font-semibold">Image URL</Form.Label>
              <Controller
                name="image"
                control={control}
                rules={{
                  required: 'Image URL is required',
                  pattern: {
                    value: /(https?:\/\/[^\s]+)/i,
                    message: 'Please enter a valid URL'
                  }
                }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter image URL"
                    className="border-gray-300 focus:ring-primary"
                  />
                )}
              />
              {errors.image && (
                <p className="text-danger mt-1">{errors.image.message}</p>
              )}
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Check
                type="switch"
                id="isNatural"
                label="Natural"
                {...register('isNatural')}
                className="custom-switch"
              />
            </Form.Group>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose} className="cancel-button">
                Cancel
              </Button>
              <Button variant="primary" type="submit" className="save-button">
                {isEditMode ? 'Update' : 'Add'}
              </Button>
            </Modal.Footer>
          </Form>
        </Modal.Body>
      </Modal>
    </Container>
  );
}