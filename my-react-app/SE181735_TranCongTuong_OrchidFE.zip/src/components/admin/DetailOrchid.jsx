import { useEffect, useState } from 'react';
import { Container, Button, Col, Row, Card, Alert, Form } from 'react-bootstrap';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import './style/DetailOrchid.css';

export default function DetailOrchid() {
    const [orchid, setOrchid] = useState({});
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [quantity, setQuantity] = useState(1);
    const { id } = useParams();
    const baseUrl = 'https://65e0222ad3db23f7624859a6.mockapi.io/Java';

    console.log('DetailOrchid: id=', id);

    const fetchData = async () => {
        if (!id) {
            setError('No ID found in URL');
            setIsLoading(false);
            console.error('No id found in params');
            return;
        }
        try {
            setIsLoading(true);
            console.log('Fetching data from:', `${baseUrl}/${id}`);
            const response = await axios.get(`${baseUrl}/${id}`);
            console.log('API response:', response.data);
            setOrchid(response.data);
            setError(null);
        } catch (error) {
            setError('Failed to fetch orchid data. Please try again later.');
            console.error('Error fetching data:', error);
            if (error.response) {
                console.error('Error response:', error.response);
            }
        } finally {
            setIsLoading(false);
        }
    };

    const addToCart = () => {
        try {
            const cart = JSON.parse(localStorage.getItem('cart')) || [];
            const existingItem = cart.find(item => item.id === orchid.id);
            if (existingItem) {
                existingItem.quantity += quantity;
            } else {
                cart.push({ ...orchid, quantity: parseInt(quantity) });
            }
            localStorage.setItem('cart', JSON.stringify(cart));
            // Dispatch custom event to notify cart update
            window.dispatchEvent(new Event('cartUpdated'));
            alert(`Added ${quantity} ${orchid.orchidName} to cart!`);
            console.log('Cart updated:', cart);
            setQuantity(1);
        } catch (err) {
            console.error('Error adding to cart:', err);
            alert('Failed to add to cart. Please try again.');
        }
    };

    const handleQuantityChange = (newQuantity) => {
        if (newQuantity >= 1) {
            setQuantity(newQuantity);
        }
    };

    useEffect(() => {
        console.log('DetailOrchid: useEffect triggered');
        fetchData();
    }, [id]);

    if (isLoading) {
        return <Container>Loading...</Container>;
    }

    if (error) {
        return <Container><Alert variant="danger">{error}</Alert></Container>;
    }

    return (
        <Container className="detail-container" style={{ minHeight: '100vh' }}>
            <Row>
                <Col md={8}>
                    <Card>
                        <Card.Body>
                            <Card.Title>{orchid.orchidName || 'N/A'}</Card.Title>
                            <Card.Text>{orchid.description || 'No description available'}</Card.Text>
                            <Card.Text>
                                <strong>Category:</strong> {orchid.category || 'N/A'}
                            </Card.Text>
                            <Card.Text>
                                <strong>Price:</strong> ${orchid.price || 'N/A'}
                            </Card.Text>
                            <Card.Text>
                                <strong>Type:</strong> {orchid.isNatural ? 'Natural' : 'Industrial'}
                            </Card.Text>
                            <Form.Group className="mb-3">
                                <Form.Label>Quantity</Form.Label>
                                <div className="d-flex align-items-center">
                                    <Button
                                        variant="outline-secondary"
                                        size="sm"
                                        onClick={() => handleQuantityChange(quantity - 1)}
                                        disabled={quantity <= 1}
                                    >
                                        -
                                    </Button>
                                    <Form.Control
                                        type="number"
                                        value={quantity}
                                        onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
                                        style={{ width: '60px', textAlign: 'center', margin: '0 10px' }}
                                        min="1"
                                    />
                                    <Button
                                        variant="outline-secondary"
                                        size="sm"
                                        onClick={() => handleQuantityChange(quantity + 1)}
                                    >
                                        +
                                    </Button>
                                </div>
                            </Form.Group>
                            <Button variant="primary" onClick={addToCart}>
                                Add to Cart
                            </Button>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card>
                        <Card.Img
                            variant="top"
                            src={orchid.image || 'https://via.placeholder.com/350'}
                            alt={orchid.orchidName || 'Orchid Image'}
                            height={350}
                        />
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}