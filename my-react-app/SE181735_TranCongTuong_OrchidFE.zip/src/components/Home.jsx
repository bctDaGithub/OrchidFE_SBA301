import { useEffect, useState } from 'react';
import { Container, Button, Col, Row, Card, Form, InputGroup, Dropdown } from 'react-bootstrap';
import axios from 'axios';
import { Link } from 'react-router-dom';
import '../style/Home.css';

export default function Home() {
    const baseUrl = import.meta.env.VITE_API_URL;
    const [api, setAPI] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [filterNatural, setFilterNatural] = useState('all'); // 'all', 'natural', 'industrial'
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            setIsLoading(true);
            const response = await axios.get(baseUrl);
            const sortedData = response.data.sort((a, b) => parseInt(b.empId) - parseInt(a.empId));
            setAPI(sortedData);
            console.log('Fetched data:', sortedData);
        } catch (error) {
            console.error('Error fetching data:', error);
        } finally {
            setIsLoading(false);
        }
    };

    // Filter orchids based on search query and natural filter
    const filteredOrchids = api.filter(item => {
        const matchesSearch = item.orchidName?.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesFilter =
            filterNatural === 'all' ||
            (filterNatural === 'natural' && item.isNatural) ||
            (filterNatural === 'industrial' && !item.isNatural);
        return matchesSearch && matchesFilter;
    });

    return (
        <Container className="home-container" style={{ minHeight: '100vh', padding: '20px' }}>
            <Row className="mb-4">
                <Col md={6}>
                    <InputGroup>
                        <InputGroup.Text>
                            <i className="fas fa-search"></i>
                        </InputGroup.Text>
                        <Form.Control
                            type="text"
                            placeholder="Search by orchid name..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </InputGroup>
                </Col>
                <Col md={3}>
                    <Dropdown onSelect={(key) => setFilterNatural(key)}>
                        <Dropdown.Toggle variant="outline-secondary" id="dropdown-natural-filter">
                            Filter: {filterNatural === 'all' ? 'All' : filterNatural === 'natural' ? 'Natural' : 'Industrial'}
                        </Dropdown.Toggle>
                        <Dropdown.Menu>
                            <Dropdown.Item eventKey="all">All</Dropdown.Item>
                            <Dropdown.Item eventKey="natural">Natural</Dropdown.Item>
                            <Dropdown.Item eventKey="industrial">Industrial</Dropdown.Item>
                        </Dropdown.Menu>
                    </Dropdown>
                </Col>
            </Row>
            {isLoading ? (
                <div>Loading...</div>
            ) : filteredOrchids.length === 0 ? (
                <div>No orchids found.</div>
            ) : (
                <Row>
                    {filteredOrchids.map((item) => (
                        <Col md={4} key={item.id} className="mb-4">
                            <Card>
                                <Card.Img
                                    variant="top"
                                    src={item.image || 'https://via.placeholder.com/350'}
                                    alt={item.orchidName || 'Orchid Image'}
                                    height={350}
                                />
                                <Card.Body>
                                    <Card.Title>{item.orchidName || 'N/A'}</Card.Title>
                                    <Link to={`/orchid/${item.id}`}>
                                        <Button variant="primary">Detail</Button>
                                    </Link>
                                </Card.Body>
                            </Card>
                        </Col>
                    ))}
                </Row>
            )}
        </Container>
    );
}