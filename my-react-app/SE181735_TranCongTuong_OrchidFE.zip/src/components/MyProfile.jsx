import React, { useEffect, useState } from 'react';
import { Container, Card, Button, Modal, Form, Col, Row } from 'react-bootstrap';
import toast, { Toaster } from 'react-hot-toast';
import { useForm, Controller } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import '../style/MyProfile.css';

// Dữ liệu giả cho người dùng
const mockUserData = {
  'admin@example.com': {
    email: 'admin@example.com',
    fullName: 'Admin User',
    password: 'Admin123!',
    role: 'admin'
  },
  'user@example.com': {
    email: 'user@example.com',
    fullName: 'Regular User',
    password: 'User123!',
    role: 'user'
  }
};

export default function MyProfile() {
  const [userData, setUserData] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const navigate = useNavigate();
  const { register, handleSubmit, formState: { errors }, reset, setValue, control } = useForm();
  const user = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    if (!user) {
      toast.error('Please log in to view your profile.');
      navigate('/login');
    } else {
      // Lấy dữ liệu giả dựa trên email từ localStorage
      const mockData = mockUserData[user.email];
      if (mockData) {
        setUserData(mockData);
      } else {
        toast.error('User data not found.');
        setUserData(null);
      }
    }
  }, [navigate, user]);

  const handleShowEdit = () => {
    if (userData) {
      setValue('fullName', userData.fullName);
      setShowModal(true);
    } else {
      toast.error('No user data available to edit.');
    }
  };

  const handleClose = () => {
    setShowModal(false);
    reset();
  };

  const onSubmit = (data) => {
    try {
      // Kiểm tra mật khẩu cũ
      if (data.oldPassword && data.oldPassword !== userData.password) {
        toast.error('Old password is incorrect.');
        return;
      }
      // Kiểm tra mật khẩu mới và xác nhận
      if (data.newPassword && data.newPassword !== data.confirmPassword) {
        toast.error('New password and confirmation do not match.');
        return;
      }
      // Cập nhật dữ liệu người dùng
      const updatedUserData = {
        ...userData,
        fullName: data.fullName,
        password: data.newPassword || userData.password
      };
      setUserData(updatedUserData);
      // Cập nhật localStorage (chỉ lưu email và role để đồng bộ với LoginForm.js)
      localStorage.setItem('user', JSON.stringify({ email: userData.email, role: userData.role }));
      toast.success('Profile updated successfully!');
      handleClose();
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error('Failed to update profile.');
    }
  };

  return (
    <Container className="my-profile-container py-8">
      <Toaster />
      <h1 className="text-3xl font-bold text-center mb-6 text-primary">My Profile</h1>
      {userData ? (
        <Card className="profile-card shadow-sm">
          <Card.Body>
            <Row>
              <Col md={6}>
                <p><strong>Email:</strong> {userData.email}</p>
                <p><strong>Full Name:</strong> {userData.fullName}</p>
                <p><strong>Role:</strong> {userData.role}</p>
              </Col>
              <Col md={6} className="text-right">
                <Button
                  variant="primary"
                  onClick={handleShowEdit}
                  className="edit-button"
                >
                  <i className="bi bi-pencil-square me-2"></i>Edit Profile
                </Button>
              </Col>
            </Row>
          </Card.Body>
        </Card>
      ) : (
        <p className="text-center text-danger mt-4">Loading user data...</p>
      )}

      <Modal show={showModal} onHide={handleClose} backdrop="static" centered>
        <Modal.Header closeButton className="bg-primary text-white">
          <Modal.Title>Edit Profile</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit(onSubmit)}>
            <Form.Group className="mb-3" controlId="email">
              <Form.Label className="font-semibold">Email (Cannot Edit)</Form.Label>
              <Form.Control
                type="email"
                value={userData?.email || ''}
                disabled
                className="border-gray-300"
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="fullName">
              <Form.Label className="font-semibold">Full Name</Form.Label>
              <Controller
                name="fullName"
                control={control}
                rules={{ required: 'Full name is required' }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="text"
                    placeholder="Enter full name"
                    className="border-gray-300 focus:ring-blue-500"
                    autoFocus
                  />
                )}
              />
              {errors.fullName && (
                <p className="text-danger mt-1">{errors.fullName.message}</p>
              )}
            </Form.Group>
            <Form.Group className="mb-3" controlId="oldPassword">
              <Form.Label className="font-semibold">Old Password</Form.Label>
              <Form.Control
                type="password"
                {...register('oldPassword')}
                placeholder="Enter old password (required if changing password)"
                className="border-gray-300 focus:ring-blue-500"
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="newPassword">
              <Form.Label className="font-semibold">New Password</Form.Label>
              <Controller
                name="newPassword"
                control={control}
                rules={{
                  minLength: {
                    value: 8,
                    message: 'Password must be at least 8 characters'
                  }
                }}
                render={({ field }) => (
                  <Form.Control
                    {...field}
                    type="password"
                    placeholder="Enter new password (optional)"
                    className="border-gray-300 focus:ring-blue-500"
                  />
                )}
              />
              {errors.newPassword && (
                <p className="text-danger mt-1">{errors.newPassword.message}</p>
              )}
            </Form.Group>
            <Form.Group className="mb-3" controlId="confirmPassword">
              <Form.Label className="font-semibold">Confirm New Password</Form.Label>
              <Form.Control
                type="password"
                {...register('confirmPassword')}
                placeholder="Confirm new password"
                className="border-gray-300 focus:ring-blue-500"
              />
            </Form.Group>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose} className="cancel-button">
                Cancel
              </Button>
              <Button variant="primary" type="submit" className="save-button">
                Save Changes
              </Button>
            </Modal.Footer>
          </Form>
        </Modal.Body>
      </Modal>
    </Container>
  );
}