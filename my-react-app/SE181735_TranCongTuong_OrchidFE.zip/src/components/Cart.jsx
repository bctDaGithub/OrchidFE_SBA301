import { useEffect, useState } from 'react';
import { Container, Button, Col, Row, Card, Alert, Form } from 'react-bootstrap';
import '../style/Cart.css'; // Ensure you have this CSS file for styling

export default function Cart() {
    const [cartItems, setCartItems] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    // Load cart items from localStorage
    useEffect(() => {
        const loadCart = () => {
            try {
                const cart = JSON.parse(localStorage.getItem('cart')) || [];
                console.log('Cart loaded from localStorage:', cart);
                setCartItems(cart);
                setError(null);
            } catch (err) {
                setError('Failed to load cart. Please try again.');
                console.error('Error loading cart:', err);
            } finally {
                setIsLoading(false);
            }
        };
        loadCart();
    }, []);

    // Update quantity of an item
    const updateQuantity = (id, newQuantity) => {
        if (newQuantity < 1) return; // Prevent quantity less than 1
        const updatedCart = cartItems.map(item =>
            item.id === id ? { ...item, quantity: newQuantity } : item
        );
        setCartItems(updatedCart);
        localStorage.setItem('cart', JSON.stringify(updatedCart));
        window.dispatchEvent(new Event('cartUpdated')); // Notify cart update
        console.log('Updated cart:', updatedCart);
    };

    // Remove item from cart
    const removeItem = (id) => {
        const updatedCart = cartItems.filter(item => item.id !== id);
        setCartItems(updatedCart);
        localStorage.setItem('cart', JSON.stringify(updatedCart));
        window.dispatchEvent(new Event('cartUpdated')); // Notify cart update
        console.log('Removed item, new cart:', updatedCart);
    };

    // Calculate total price
    const calculateTotal = () => {
        return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0).toFixed(2);
    };

    // Handle checkout (placeholder)
    const handleCheckout = () => {
        alert('Proceeding to checkout (placeholder).');
        // Implement checkout logic here
    };

    if (isLoading) {
        return <Container>Loading...</Container>;
    }

    if (error) {
        return <Container><Alert variant="danger">{error}</Alert></Container>;
    }

    if (cartItems.length === 0) {
        return <Container><Alert variant="info">Your cart is empty.</Alert></Container>;
    }

    return (
        <Container className="cart-container" style={{ minHeight: '100vh', padding: '20px' }}>
            <h2>Your Cart</h2>
            <Row>
                <Col md={8}>
                    {cartItems.map(item => (
                        <Card key={item.id} className="mb-3">
                            <Card.Body>
                                <Row>
                                    <Col md={3}>
                                        <Card.Img
                                            src={item.image || 'https://via.placeholder.com/150'}
                                            alt={item.orchidName}
                                            style={{ height: '100px', objectFit: 'cover' }}
                                        />
                                    </Col>
                                    <Col md={5}>
                                        <Card.Title>{item.orchidName || 'N/A'}</Card.Title>
                                        <Card.Text>
                                            <strong>Price:</strong> ${item.price || 'N/A'}
                                        </Card.Text>
                                        <Card.Text>
                                            <strong>Total:</strong> ${(item.price * item.quantity).toFixed(2)}
                                        </Card.Text>
                                    </Col>
                                    <Col md={4}>
                                        <Form.Group className="mb-3">
                                            <Form.Label>Quantity</Form.Label>
                                            <div className="d-flex align-items-center">
                                                <Button
                                                    variant="outline-secondary"
                                                    size="sm"
                                                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                                    disabled={item.quantity <= 1}
                                                >
                                                    -
                                                </Button>
                                                <Form.Control
                                                    type="number"
                                                    value={item.quantity}
                                                    onChange={(e) => updateQuantity(item.id, parseInt(e.target.value) || 1)}
                                                    style={{ width: '60px', textAlign: 'center', margin: '0 10px' }}
                                                    min="1"
                                                />
                                                <Button
                                                    variant="outline-secondary"
                                                    size="sm"
                                                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                                >
                                                    +
                                                </Button>
                                            </div>
                                        </Form.Group>
                                        <Button
                                            variant="danger"
                                            size="sm"
                                            onClick={() => removeItem(item.id)}
                                        >
                                            Remove
                                        </Button>
                                    </Col>
                                </Row>
                            </Card.Body>
                        </Card>
                    ))}
                </Col>
                <Col md={4}>
                    <Card>
                        <Card.Body>
                            <Card.Title>Order Summary</Card.Title>
                            <Card.Text>
                                <strong>Total:</strong> ${calculateTotal()}
                            </Card.Text>
                            <Button
                                variant="primary"
                                onClick={handleCheckout}
                                disabled={cartItems.length === 0}
                            >
                                Proceed to Checkout
                            </Button>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}